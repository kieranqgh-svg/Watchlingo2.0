# WatchLingo
Original Wear OS language-learning prototype designed around the circular Galaxy Watch7 display.

## Included
- Watch-first circular UI
- Multiple question types scaffold
- XP and streaks
- Grammar screen
- Japanese handwriting/drawing practice using the watch touchscreen
- Language/course architecture ready for expanded course data

## Important
This project does not contain Duolingo source code, proprietary lesson data, audio, artwork, or other copyrighted assets. Those would need to be replaced with original or properly licensed content.

Open the project in Android Studio and build/install the Wear OS APK.
