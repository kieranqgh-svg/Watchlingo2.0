package com.watchlingo

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.*
import kotlin.math.*

/** Original Wear OS language-learning prototype. No Duolingo proprietary code/content included. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(WatchLingoView()) }

    inner class WatchLingoView : View(this) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke = Path()
        private var screen = Screen.HOME
        private var language = "Japanese"
        private var target = "あ"
        private var question = 0
        private var xp = 0
        private var streak = 1
        private var drawing = false
        private var feedback = ""

        enum class Screen { HOME, LESSON, DRAW, GRAMMAR }
        data class Q(val prompt:String,val answers:List<String>,val correct:Int)
        private val qs = listOf(
            Q("Choose the translation", listOf("hello","water","friend"), 0),
            Q("Pick the missing word: I ___ coffee", listOf("drink","drinks","drank"), 0),
            Q("Arrange the sentence", listOf("I like apples","Apples I like","Like I apples"), 0),
            Q("Grammar: She ___ two cats", listOf("have","has","having"), 1)
        )

        init { paint.strokeCap=Paint.Cap.ROUND; isFocusable=true }
        override fun onDraw(c:Canvas) {
            c.drawColor(Color.BLACK); val w=width.toFloat(); val h=height.toFloat(); val s=min(w,h)
            paint.textAlign=Paint.Align.CENTER; paint.style=Paint.Style.FILL; paint.color=Color.WHITE
            paint.textSize=s*.075f
            when(screen){
                Screen.HOME -> { text(c,"WatchLingo",w/2,h*.14f,s*.09f); text(c,"Galaxy Watch7 edition",w/2,h*.21f,s*.045f,Color.LTGRAY); text(c,"🌍 $language",w/2,h*.34f,s*.06f); text(c,"🔥 $streak     ⭐ $xp XP",w/2,h*.44f,s*.05f); button(c,"START LESSON",w/2,h*.61f,s*.23f); button(c,"JAPANESE DRAWING",w/2,h*.76f,s*.19f) }
                Screen.LESSON -> drawQuestion(c,w,h,s)
                Screen.GRAMMAR -> drawGrammar(c,w,h,s)
                Screen.DRAW -> drawCanvas(c,w,h,s)
            }
        }
        private fun drawQuestion(c:Canvas,w:Float,h:Float,s:Float){ val q=qs[question%qs.size]; text(c,"$language  •  ${question+1}/${qs.size}",w/2,h*.13f,s*.045f,Color.LTGRAY); text(c,q.prompt,w/2,h*.28f,s*.07f); q.answers.forEachIndexed{ i,a -> button(c,a,w/2,h*(.45f+i*.14f),s*.13f)}; text(c,feedback,w/2,h*.90f,s*.045f,Color.WHITE) }
        private fun drawGrammar(c:Canvas,w:Float,h:Float,s:Float){ text(c,"GRAMMAR",w/2,h*.15f,s*.08f); text(c,"She ___ two cats",w/2,h*.31f,s*.07f); listOf("have","has","having").forEachIndexed{i,a->button(c,a,w/2,h*(.48f+i*.14f),s*.13f)} }
        private fun drawCanvas(c:Canvas,w:Float,h:Float,s:Float){ text(c,"日本語",w/2,h*.12f,s*.07f); text(c,"Draw: $target",w/2,h*.23f,s*.055f); paint.style=Paint.Style.STROKE;paint.strokeWidth=3f;paint.color=Color.DKGRAY;c.drawCircle(w/2,h*.55f,s*.28f,paint);c.drawLine(w*.32f,h*.55f,w*.68f,h*.55f,paint);c.drawLine(w*.5f,h*.27f,w*.5f,h*.83f,paint);paint.color=Color.WHITE;paint.strokeWidth=8f;c.drawPath(stroke,paint);paint.style=Paint.Style.FILL;text(c,"Tap outside circle to clear",w/2,h*.91f,s*.04f,Color.LTGRAY) }
        private fun text(c:Canvas,t:String,x:Float,y:Float,size:Float,color:Int=Color.WHITE){paint.style=Paint.Style.FILL;paint.color=color;paint.textSize=size;c.drawText(t,x,y,paint)}
        private fun button(c:Canvas,t:String,x:Float,y:Float,r:Float){paint.style=Paint.Style.STROKE;paint.strokeWidth=2f;paint.color=Color.GRAY;c.drawRoundRect(x-r,y-r*.42f,x+r,y+r*.42f,r*.3f,r*.3f,paint);text(c,t,x,y+r*.12f,r*.38f)}
        override fun onTouchEvent(e:MotionEvent):Boolean{
            val w=width.toFloat();val h=height.toFloat();val s=min(w,h);val cx=w/2;val cy=h*.55f
            when(screen){
                Screen.HOME->if(e.action==MotionEvent.ACTION_UP){ if(e.y>h*.52f&&e.y<h*.70f)screen=Screen.LESSON else if(e.y>h*.68f)screen=Screen.DRAW;invalidate() }
                Screen.LESSON->if(e.action==MotionEvent.ACTION_UP){ if(e.y>h*.38f&&e.y<h*.88f){xp+=10;question++;feedback="✓ +10 XP"; if(question%4==0)streak++;invalidate()} }
                Screen.DRAW->when(e.action){ MotionEvent.ACTION_DOWN->{ if(hypot(e.x-cx,e.y-cy)<s*.28f){stroke.moveTo(e.x,e.y);drawing=true}else{stroke.reset()};invalidate()}; MotionEvent.ACTION_MOVE->{if(drawing){stroke.lineTo(e.x,e.y);invalidate()}}; MotionEvent.ACTION_UP->{drawing=false;invalidate()} }
                Screen.GRAMMAR->if(e.action==MotionEvent.ACTION_UP){xp+=15;invalidate()}
            }; return true
        }
    }
}
